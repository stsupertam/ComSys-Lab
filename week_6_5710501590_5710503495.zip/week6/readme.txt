Santitham  Ananwattanaporn  5710501590
Parut      Singhapun 	    5710503495

gcc -o mutex matching_mutex.c -lpthread -> complie
./mutex FILENAME -> run

gcc -o con matching_con.c -lpthread -> complie
./con FILENAME -> run