5710501590 Santitham Ananwattanaporn
5710503495 Parut Singhapun
----------------------------------------------
Problem 1
----------------------------------------------
-prob1
$ gcc -o -pthread prob1 prob1.c
$ ./prob1
----------------------------------------------
Problem 2
----------------------------------------------
-prob2a
$ gcc -o prob2a prob2a.c
$ ./prob2a

-prob2b
$ gcc -o prob2b prob2b.c
$ ./prob2b
----------------------------------------------
Problem 3
----------------------------------------------
-prob3a
$ gcc -o -pthread prob3a prob3a.c
$ ./prob3a [DIR]

-prob3b
$ gcc -o prob3a prob3a.c
$ ./prob3b [DIR]
----------------------------------------------